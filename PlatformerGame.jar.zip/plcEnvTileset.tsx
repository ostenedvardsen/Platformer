<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.1" name="plcEnvTileset" tilewidth="32" tileheight="32" tilecount="64" columns="8">
 <image source="plcGraphics/plcEnvTileset.png" width="256" height="256"/>
</tileset>
