<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.1" name="plcGround" tilewidth="32" tileheight="32" tilecount="1" columns="1">
 <image source="plcGraphics/plcGround.jpg" width="32" height="32"/>
</tileset>
